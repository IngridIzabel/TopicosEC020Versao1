/*
 * Sensor.c
 *
 *  Created on: 19/09/2016
 *      Author: edielson
 */

#include "lpc17xx_pinsel.h"
#include "lpc17xx_i2c.h"
#include "lpc17xx_gpio.h"
#include "lpc17xx_ssp.h"
#include "lpc17xx_adc.h"
#include "lpc17xx_timer.h"
#include "rgb.h"
#include "oled.h"
#include "temp.h"

uint32_t ADC_Interrupt_Done_Flag = 0;
uint32_t t = 0;

static void init_ssp(void);//para habilitar oled -> tela
static void Sensor_initADC(void);


typedef struct tag_sensor
{
	int sensor_data;
}ttag_sensor;


ttag_sensor ClassHandle;


void Sensor_new(void)
{
	init_ssp();
	Sensor_initADC();

	oled_init();

}

int Sensor_read(void)
{
	ADC_Interrupt_Done_Flag = 0;
	NVIC_EnableIRQ(ADC_IRQn);
	/* analog input connected to BNC */
	ADC_StartCmd(LPC_ADC,ADC_START_NOW);
	return ClassHandle.sensor_data;
}

static void Sensor_initADC(void)
{
	PINSEL_CFG_Type PinCfg;

	/*
	 * Init ADC pin connect
	 * AD0.5 on P1.31
	 */
	PinCfg.Funcnum = 3;
	PinCfg.OpenDrain = 0;
	PinCfg.Pinmode = 0;
	PinCfg.Pinnum = 31;
	PinCfg.Portnum = 1;
	PINSEL_ConfigPin(&PinCfg);

	/* Configuration for ADC :
	 * 	Frequency at 1Mhz
	 *  ADC channel 5, no Interrupt
	 */
	ADC_Init(LPC_ADC, 1000000);

	NVIC_EnableIRQ(ADC_IRQn);
	ADC_IntConfig(LPC_ADC,ADC_CHANNEL_5,ENABLE);
	ADC_ChannelCmd(LPC_ADC,ADC_CHANNEL_5,ENABLE);
	ADC_EdgeStartConfig(LPC_ADC, ADC_START_ON_RISING);
	ADC_StartCmd(LPC_ADC,ADC_START_NOW);

}

static void init_ssp(void)
{
	SSP_CFG_Type SSP_ConfigStruct;
	PINSEL_CFG_Type PinCfg;

	/*
	 * Initialize SPI pin connect
	 * P0.7 - SCK;
	 * P0.8 - MISO
	 * P0.9 - MOSI
	 * P2.2 - SSEL - used as GPIO
	 */
	PinCfg.Funcnum = 2;
	PinCfg.OpenDrain = 0;
	PinCfg.Pinmode = 0;
	PinCfg.Portnum = 0;
	PinCfg.Pinnum = 7;
	PINSEL_ConfigPin(&PinCfg);
	PinCfg.Pinnum = 8;
	PINSEL_ConfigPin(&PinCfg);
	PinCfg.Pinnum = 9;
	PINSEL_ConfigPin(&PinCfg);
	PinCfg.Funcnum = 0;
	PinCfg.Portnum = 2;
	PinCfg.Pinnum = 2;
	PINSEL_ConfigPin(&PinCfg);

	SSP_ConfigStructInit(&SSP_ConfigStruct);

	// Initialize SSP peripheral with parameter given in structure above
	SSP_Init(LPC_SSP1, &SSP_ConfigStruct);

	// Enable SSP peripheral
	SSP_Cmd(LPC_SSP1, ENABLE);

}

void TIMER0_IRQHandler(void){//trata a interrrupÃ§Ã£o
	NVIC_DisableIRQ(TIMER0_IRQn);
	t = temp_read();
	ADC_Interrupt_Done_Flag = 1;
}
