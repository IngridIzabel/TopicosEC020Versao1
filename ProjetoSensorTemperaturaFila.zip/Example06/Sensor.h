/*
 * Sensor.h
 *
 *  Created on: 19/09/2016
 *      Author: edielson
 */

#ifndef SENSOR_H_
#define SENSOR_H_

void Sensor_new(uint32_t (*getMsTick)(void));
int Sensor_read(void);

#endif /* SENSOR_H_ */
