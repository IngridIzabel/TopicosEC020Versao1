#include "lpc17xx_pinsel.h"
#include "lpc17xx_i2c.h"
#include "lpc17xx_gpio.h"
#include "lpc17xx_ssp.h"
#include "lpc17xx_adc.h"
#include "lpc17xx_timer.h"
#include "rgb.h"
#include "oled.h"
#include "temp.h"

void Led_new(void)
{
	oled_clearScreen(OLED_COLOR_WHITE);
	oled_putString(1,1,  (uint8_t*)"TEMP: ", OLED_COLOR_BLACK, OLED_COLOR_WHITE);

}
void Led_liga(uint8_t buf[10])
{
	oled_fillRect((1+6*6),1, 80, 8, OLED_COLOR_WHITE);
	oled_putString((1+6*6),1, buf, OLED_COLOR_BLACK, OLED_COLOR_WHITE);
}
