/*
 * Led.h
 *
 *  Created on: 19/09/2016
 *      Author: edielson
 */

#ifndef LED_H_
#define LED_H_

void Led_new(void);
void Led_liga(uint8_t buf[10]);

#endif /* LED_H_ */
